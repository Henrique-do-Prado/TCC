#!/usr/bin/env bash
# coleta.sh — Coleta principal do TCC "Performance e Benchmark do Sistema FUSE no Linux"
#
# Cada invocação executa UMA repetição completa da matriz experimental
# (5 configurações × 5 tamanhos × 4 cargas × 4 níveis de concorrência = 400
# execuções, ~5,2 h), em ordem aleatorizada própria daquela repetição.
# As 5 repetições são executadas em sessões separadas (uma por noite), de modo
# que cada repetição constitui um bloco completo (Seção 3.6.4).
#
# Uso normal (como root, em modo texto, dentro do tmux):
#   sudo REP=1 PT_HP=/home/hen/tcc-scripts/coleta/libfuse/example/passthrough_hp \
#        systemd-inhibit --what=sleep:idle:handle-lid-switch ./coleta.sh
#
# Teste rápido (10 execuções curtas, ~2 min, resultados em pasta separada):
#   sudo TESTE=1 PT_HP=/caminho/passthrough_hp ./coleta.sh
#
# Só listar a ordem de uma repetição, sem executar nada (não precisa de root):
#   REP=1 LISTAR=1 ./coleta.sh
#
# O script é retomável: execuções com JSON final já gravado são puladas.
# Execuções que falham são registradas em falhas.txt e a coleta continua.

set -uo pipefail

# ------------------------------------------------------------- configuração
PT_HP="${PT_HP:-/home/hen/tcc-scripts/coleta/libfuse/example/passthrough_hp}"
SRC_DIR="${SRC_DIR:-/srv/fusebench/base}"   # diretório no ext4 do NVMe
MNT="${MNT:-/srv/fusebench/mnt}"            # ponto de montagem do FUSE
DEV="${DEV:-/dev/nvme0n1}"                  # namespace NVMe (para o iostat)
NVME_CTRL="${NVME_CTRL:-/dev/nvme0}"        # controlador NVMe (para o SMART)
BASE_RESULTS="${BASE_RESULTS:-$PWD/resultados_coleta}"
KERNEL_ESPERADO="${KERNEL_ESPERADO:-7.1.1-76070101-generic}"

REP="${REP:-}"
TESTE="${TESTE:-0}"
LISTAR="${LISTAR:-0}"

FILE_GIB=80        # arquivo de teste: ~10x a memória principal
RUNTIME=40         # segundos de medição (Seção 3.6.2)
RAMP=5             # segundos de warm-up descartados (Seção 3.6.2)
SEED=20261110      # semente-base; a ordem de cada repetição usa SEED + REP

CONFIGS=(nativo fuse-base fuse-cache fuse-splice fuse-mt)
BSS=(4k 16k 64k 256k 1m)
RWS=(read write randread randwrite)
CONCS=(1 2 4 8)

# Opções do passthrough_hp 3.10.5 por configuração (Seção 3.4.3)
opcoes_fuse() {
  case "$1" in
    fuse-base)   echo "--nocache --nosplice --single" ;;
    fuse-cache)  echo "--nosplice --single" ;;
    fuse-splice) echo "--nocache --single" ;;
    fuse-mt)     echo "" ;;
    *)           echo "" ;;
  esac
}

# ----------------------------------------------------------------- funções
log() { printf '[%(%d/%m %H:%M:%S)T] %s\n' -1 "$*"; }
die() { log "ERRO: $*"; exit 1; }

IOSTAT_PID=""
FUSE_PID=""

desmontar() {
  if mountpoint -q "$MNT" 2>/dev/null; then
    fusermount3 -u "$MNT" 2>/dev/null || umount "$MNT" 2>/dev/null || umount -l "$MNT"
  fi
  if [[ -n "$FUSE_PID" ]]; then
    wait "$FUSE_PID" 2>/dev/null || true
    FUSE_PID=""
  fi
}

parar_iostat() {
  if [[ -n "$IOSTAT_PID" ]]; then
    kill "$IOSTAT_PID" 2>/dev/null || true
    wait "$IOSTAT_PID" 2>/dev/null || true
    IOSTAT_PID=""
  fi
}

limpar() { parar_iostat; desmontar; }

montar_fuse() {  # $1 = configuração, $2 = arquivo de log
  local -a opts
  read -r -a opts <<< "$(opcoes_fuse "$1")"
  opts+=("${EXTRA_FUSE_OPTS[@]}")
  "$PT_HP" "${opts[@]}" "$SRC_DIR" "$MNT" > "$2" 2>&1 &
  FUSE_PID=$!
  for _ in $(seq 50); do
    mountpoint -q "$MNT" && return 0
    sleep 0.2
  done
  return 1
}

# ------------------------------------------------- definição das execuções
if [[ "$TESTE" == 1 ]]; then
  REP=0
  RUNTIME=5
  RAMP=1
  RESULTS="$BASE_RESULTS/teste"
  lista=()
  for cfg in "${CONFIGS[@]}"; do
    lista+=("$cfg 4k read 1" "$cfg 64k randwrite 4")
  done
else
  [[ "$REP" =~ ^[1-5]$ ]] || die "defina REP=1 a 5 (a repetição desta sessão)."
  RESULTS="$BASE_RESULTS/rep$REP"
  lista=()
  for cfg in "${CONFIGS[@]}"; do
    for bs in "${BSS[@]}"; do
      for rw in "${RWS[@]}"; do
        for nj in "${CONCS[@]}"; do
          lista+=("$cfg $bs $rw $nj")
        done
      done
    done
  done
fi

# Ordem aleatorizada, mas determinística (mesma semente => mesma ordem).
# O fluxo pseudoaleatório é derivado da semente via AES-CTR (receita do manual
# do GNU coreutils para --random-source), de modo que sementes vizinhas geram
# ordens independentes.
SEED_REP=$((SEED + REP))
fonte_aleatoria() {
  openssl enc -aes-256-ctr -pass pass:"$1" -nosalt -pbkdf2 < /dev/zero 2>/dev/null
}
command -v openssl > /dev/null || die "comando ausente: openssl."
mapfile -t ordem < <(printf '%s\n' "${lista[@]}" | shuf --random-source=<(fonte_aleatoria "$SEED_REP"))
total=${#ordem[@]}

if [[ "$LISTAR" == 1 ]]; then
  printf '%s\n' "${ordem[@]}"
  exit 0
fi

# ---------------------------------------------------------- pré-requisitos
[[ $EUID -eq 0 ]] || die "execute como root (sudo)."
for cmd in fio iostat nvme fusermount3 mountpoint findmnt shuf stdbuf flock; do
  command -v "$cmd" > /dev/null || die "comando ausente: $cmd (instale fio, sysstat, nvme-cli, fuse3)."
done
[[ -x "$PT_HP" ]] || die "passthrough_hp não encontrado em '$PT_HP' (ajuste a variável PT_HP)."
[[ -b "$DEV" ]] || die "dispositivo $DEV não encontrado."

mkdir -p "$SRC_DIR" "$MNT" "$RESULTS"

# Impede duas coletas simultâneas.
exec 9> "$BASE_RESULTS/.trava"
flock -n 9 || die "já existe uma coleta em andamento."

trap limpar EXIT
trap 'log "Interrompido."; exit 130' INT TERM

fstype=$(findmnt -no FSTYPE -T "$SRC_DIR")
[[ "$fstype" == ext4 ]] || die "$SRC_DIR está em '$fstype', não em ext4."

# Kernel fixo durante toda a coleta.
kernel=$(uname -r)
[[ "$kernel" == "$KERNEL_ESPERADO" ]] || \
  die "kernel atual é '$kernel', esperado '$KERNEL_ESPERADO'. Não misture kernels entre repetições."

# Perfil de energia e interface gráfica: obrigatórios na coleta, avisos no teste.
perfil=$(system76-power profile 2>/dev/null | head -n1 || echo desconhecido)
if ! grep -qi performance <<< "$perfil"; then
  if [[ "$TESTE" == 1 ]]; then
    log "AVISO: perfil de energia é '$perfil' (aceitável só no teste)."
  else
    die "perfil de energia é '$perfil'. Rode: system76-power profile performance"
  fi
fi
if systemctl is-active --quiet graphical.target; then
  if [[ "$TESTE" == 1 ]]; then
    log "AVISO: interface gráfica ativa (aceitável só no teste)."
  else
    log "AVISO: interface gráfica ativa. Recomendado: systemctl isolate multi-user.target"
    log "       Continuando em 15 s (Ctrl+C para cancelar)..."
    sleep 15
  fi
fi

# Versões da libfuse >= 3.16 usam o passthrough nativo do kernel por padrão,
# o que tiraria o daemon do caminho de dados. A 3.10.5 não tem essa opção.
EXTRA_FUSE_OPTS=()
if { "$PT_HP" --help 2>&1 || true; } | grep -q -- '--nopassthrough'; then
  EXTRA_FUSE_OPTS+=(--nopassthrough)
  log "passthrough_hp suporta passthrough nativo do kernel; usando --nopassthrough."
fi

# ---------------------------------------------------- registro do ambiente
meta="$RESULTS/ambiente.txt"
if [[ ! -s "$meta" ]]; then
  {
    echo "data: $(date -Is)"
    echo "repeticao: $REP (teste=$TESTE)"
    echo "kernel: $kernel"
    echo "fio: $(fio --version)"
    echo "openssl (gera a ordem): $(openssl version)"
    echo "libfuse (pkg-config): $(pkg-config --modversion fuse3 2>/dev/null || echo desconhecida)"
    echo "passthrough_hp: $PT_HP"
    echo "opcoes extras FUSE: ${EXTRA_FUSE_OPTS[*]:-(nenhuma)}"
    for c in "${CONFIGS[@]}"; do echo "  $c: $(opcoes_fuse "$c")"; done
    echo "perfil de energia: $perfil"
    echo "interface grafica ativa: $(systemctl is-active graphical.target 2>/dev/null || true)"
    echo "params: FILE_GIB=$FILE_GIB RUNTIME=$RUNTIME RAMP=$RAMP SEED=$SEED SEED_REP=$SEED_REP"
    echo
    lsblk -o NAME,TYPE,FSTYPE,SIZE,MOUNTPOINT
    echo
    lspci -vv 2>/dev/null | grep -A40 'Non-Volatile' | grep -E 'LnkCap|LnkSta' || true
    echo
    free -h
  } > "$meta"
fi
printf '%s\n' "${ordem[@]}" > "$RESULTS/ordem.txt"

nvme smart-log "$NVME_CTRL" -o json > "$RESULTS/smart_inicio_$(date +%s).json"

# --------------------------------------------------------- arquivo de teste
# Reaproveita o arquivo do piloto se ele tiver exatamente o tamanho esperado.
# Escrita real (e não fallocate): leituras de extents não escritos devolvem
# zeros sem acessar o disco, o que invalidaria as medições de leitura.
TESTFILE="$SRC_DIR/teste.dat"
want=$((FILE_GIB * 1024 * 1024 * 1024))
have=$(stat -c %s "$TESTFILE" 2>/dev/null || echo 0)
if [[ "$have" -eq "$want" ]]; then
  log "Arquivo de teste de ${FILE_GIB} GiB encontrado; reaproveitando."
else
  rm -f "$TESTFILE"
  free_b=$(df --output=avail -B1 "$SRC_DIR" | tail -n1)
  (( free_b > want + 10 * 1024 * 1024 * 1024 )) || die "espaço insuficiente em $SRC_DIR."
  log "Criando arquivo de teste de ${FILE_GIB} GiB (alguns minutos)..."
  fio --name=layout --filename="$TESTFILE" --rw=write --bs=1m --size="${FILE_GIB}g" \
      --ioengine=psync --direct=1 --end_fsync=1 \
      --output-format=json --output="$RESULTS/layout.json" || die "falha ao criar o arquivo de teste."
fi

# ---------------------------------------------------------------- execução
feitas=0
for linha in "${ordem[@]}"; do [[ -s "$RESULTS/$(tr ' ' '_' <<< "$linha").json" ]] && feitas=$((feitas+1)); done
restantes=$((total - feitas))
log "Repetição $REP: $total execuções ($feitas já concluídas, $restantes restantes)."
log "Duração estimada: ~$(( restantes * (RUNTIME + RAMP + 2) / 60 )) min."

inicio=$(date +%s)
falhas=0
i=0
for linha in "${ordem[@]}"; do
  i=$((i + 1))
  read -r cfg bs rw nj <<< "$linha"
  id="${cfg}_${bs}_${rw}_${nj}"
  p="$RESULTS/$id"

  [[ -s "$p.json" ]] && continue
  log "[$i/$total] $cfg  bs=$bs  $rw  jobs=$nj"

  # (i) desmontagem residual; (ii) sincronização e limpeza de caches
  desmontar
  sync
  echo 3 > /proc/sys/vm/drop_caches

  # (iii) montagem do FUSE, quando aplicável
  if [[ "$cfg" == nativo ]]; then
    alvo="$TESTFILE"
  else
    if ! montar_fuse "$cfg" "$p.fuse.log"; then
      log "  FALHA ao montar o FUSE; tentando de novo em 5 s..."
      desmontar; sleep 5
      if ! montar_fuse "$cfg" "$p.fuse.log"; then
        log "  FALHA definitiva na montagem (veja $p.fuse.log); pulando."
        echo "$(date -Is) $id montagem" >> "$RESULTS/falhas.txt"
        falhas=$((falhas + 1)); desmontar; continue
      fi
    fi
    alvo="$MNT/teste.dat"
  fi

  # (iv) execução do fio com os parâmetros da célula (Seção 3.6.2)
  por_job=$((FILE_GIB / nj))
  args=(--name="$id" --filename="$alvo" --allow_file_create=0
        --ioengine=psync --direct=0 --iodepth=1 --rw="$rw" --bs="$bs"
        --numjobs="$nj" --size="${por_job}g" --offset_increment="${por_job}g"
        --randseed=$((SEED_REP * 1000 + i)) --group_reporting=1
        --ramp_time="$RAMP" --runtime="$RUNTIME" --time_based=1
        --write_bw_log="$p" --log_avg_msec=1000
        --output-format=json+ --output="$p.json.tmp")
  [[ "$rw" == *write* ]] && args+=(--end_fsync=1)

  nvme smart-log "$NVME_CTRL" -o json > "$p.smart_antes.json" 2>/dev/null || true
  LC_ALL=C stdbuf -oL iostat -dxmty 1 "$(basename "$DEV")" > "$p.iostat.txt" &
  IOSTAT_PID=$!

  if fio "${args[@]}" > "$p.fio.log" 2>&1; then
    ok=1
  else
    ok=0
  fi

  parar_iostat
  nvme smart-log "$NVME_CTRL" -o json > "$p.smart_depois.json" 2>/dev/null || true

  # (v) gravação do resultado; (vi) desmontagem
  desmontar
  if (( ok )) && [[ -s "$p.json.tmp" ]]; then
    mv "$p.json.tmp" "$p.json"
  else
    log "  FALHA no fio (veja $p.fio.log); registrada e pulada."
    echo "$(date -Is) $id fio" >> "$RESULTS/falhas.txt"
    falhas=$((falhas + 1))
  fi

  # Projeção do tempo restante a cada 20 execuções
  if (( i % 20 == 0 )); then
    decorrido=$(( $(date +%s) - inicio ))
    feitas_agora=0
    for l in "${ordem[@]}"; do [[ -s "$RESULTS/$(tr ' ' '_' <<< "$l").json" ]] && feitas_agora=$((feitas_agora+1)); done
    novas=$(( feitas_agora - feitas ))
    if (( novas > 0 )); then
      log "  Progresso: $feitas_agora/$total; ~$(( decorrido / novas )) s por execução;" \
          "faltam ~$(( (total - feitas_agora) * decorrido / novas / 60 )) min."
    fi
  fi
done

nvme smart-log "$NVME_CTRL" -o json > "$RESULTS/smart_fim_$(date +%s).json"
concluidas=0
for linha in "${ordem[@]}"; do [[ -s "$RESULTS/$(tr ' ' '_' <<< "$linha").json" ]] && concluidas=$((concluidas+1)); done
log "Fim da repetição $REP: $concluidas/$total concluídas, $falhas falhas nesta sessão."
if (( concluidas < total )); then
  log "Rode o mesmo comando de novo para completar as que faltam."
else
  date -Is > "$RESULTS/CONCLUIDA"
fi
