#!/usr/bin/env python3
"""analisa_p1_p4.py — Análise dos testes complementares P1 e P4 (revisão de 16/11/2026).

Uso:
    python3 analisa_p1_p4.py resultados_extra

P1: para cada condição (padrao, semdica, semra), compara NATIVO e FUSE-mt na leitura
    aleatória de 1 MiB com 1 job: medianas, R_T, R_50/95/99, (C1)-(C5) com o mesmo
    Mann-Whitney exato da coleta, e, no disco, volume lido / volume do fio, fila média
    (aqu-sz) e tamanho médio das requisições (rareq-sz).
P4: a partir do strace -c do daemon, conta as chamadas de atributos (newfstatat, statx,
    fstat — o getattr do passthrough_hp), as leituras de dados (pread64, preadv...) e as
    requisições lidas de /dev/fuse, e divide pelo número de read() feitos pelo fio.

Grava o relatório em resultados_extra/relatorio_p1_p4.txt.
"""
import glob
import itertools
import json
import os
import re
import statistics as st
import sys
from collections import defaultdict

EPS = DELTA = 0.05
ALPHA = 0.05
RAMP, RUNTIME = 5, 40
PCT = {"p50": "50.000000", "p95": "95.000000", "p99": "99.000000"}
METRICAS = ["T", "p50", "p95", "p99"]
CONDS = ["padrao", "semdica", "semra"]
DESC = {"padrao": "igual à coleta (fadvise_hint padrão)",
        "semdica": "fadvise_hint=0 (NATIVO também com readahead)",
        "semra": "readahead do dispositivo do ext4 = 0 (daemon sem readahead)"}


def ler_json(caminho):
    texto = open(caminho, encoding="utf-8", errors="replace").read()
    return json.loads(texto[texto.index("{"):])


def iostat(caminho):
    """Volume lido (MiB), fila média e tamanho médio das requisições de leitura (KiB),
    estes dois só nos intervalos com leitura."""
    hdr, mib, aqu, rsz = None, 0.0, [], []
    try:
        for linha in open(caminho, encoding="utf-8", errors="replace"):
            p = linha.split()
            if not p:
                continue
            if p[0].startswith("Device"):
                hdr = p
                continue
            if hdr and p[0].startswith("nvme") and len(p) == len(hdr):
                d = {k: float(v.replace(",", ".")) for k, v in zip(hdr[1:], p[1:])}
                mib += d.get("rMB/s", 0.0)
                if d.get("r/s", 0) > 0:
                    if "aqu-sz" in d:
                        aqu.append(d["aqu-sz"])
                    if "rareq-sz" in d:
                        rsz.append(d["rareq-sz"])
    except OSError:
        pass
    m = lambda v: st.mean(v) if v else float("nan")
    return mib, m(aqu), m(rsz)


# ------------------------------------------------- Mann-Whitney (igual à coleta)
def u_desfavoravel(fuse, nat_aj, maior_melhor):
    u = 0.0
    for x in fuse:
        for y in nat_aj:
            if x == y:
                u += 0.5
            elif (x < y) if maior_melhor else (x > y):
                u += 1
    return u


def mann_whitney(fuse, nativo, maior_melhor, tol):
    fator = (1 - tol) if maior_melhor else (1 + tol)
    nat_aj = [v * fator for v in nativo]
    u_obs = u_desfavoravel(fuse, nat_aj, maior_melhor)
    todos = list(fuse) + nat_aj
    n = len(fuse)
    extremos = total = 0
    for idx in itertools.combinations(range(len(todos)), n):
        s = set(idx)
        a = [todos[i] for i in idx]
        b = [todos[i] for i in range(len(todos)) if i not in s]
        total += 1
        if u_desfavoravel(a, b, maior_melhor) <= u_obs + 1e-9:
            extremos += 1
    return u_obs, extremos / total


def fmt(v, casas=2):
    return f"{v:.{casas}f}".replace(".", ",") if v == v else "—"


# ====================================================================== P1
def p1(base, w):
    execs = defaultdict(list)
    for arq in sorted(glob.glob(os.path.join(base, "p1", "*.json"))):
        m = re.match(r"(\w+?)_(nativo|fuse-[a-z]+)_r(\d+)\.json$", os.path.basename(arq))
        if not m:
            continue
        cond, cfg, rep = m.group(1), m.group(2), int(m.group(3))
        j = ler_json(arq)
        d = j["jobs"][0]["read"]
        pc = d["clat_ns"].get("percentile", {})
        disco, aqu, rsz = iostat(arq[:-5] + ".iostat.txt")
        fio_mib = d["io_bytes"] / 2**20
        esperado = fio_mib * (RAMP + RUNTIME) / RUNTIME
        info = open(arq[:-5] + ".info").read().strip() if os.path.isfile(arq[:-5] + ".info") else ""
        execs[(cond, cfg)].append({
            "rep": rep, "T": d["bw_bytes"] / 2**20,
            "p50": pc.get(PCT["p50"], float("nan")) / 1000,
            "p95": pc.get(PCT["p95"], float("nan")) / 1000,
            "p99": pc.get(PCT["p99"], float("nan")) / 1000,
            "disco_fio": disco / esperado if esperado else float("nan"),
            "aqu": aqu, "rsz": rsz, "info": info})

    w("=" * 78)
    w("P1 — Leitura aleatória de 1 MiB, 1 job (NATIVO × FUSE)")
    w("=" * 78)
    if not execs:
        w("Nenhum resultado em p1/.\n")
        return
    fuses = sorted({cfg for (_, cfg) in execs if cfg != "nativo"})
    for cond in CONDS:
        if (cond, "nativo") not in execs:
            continue
        w(f"\n--- {cond}: {DESC[cond]}")
        ras = sorted({e["info"] for k, v in execs.items() if k[0] == cond for e in v})
        w(f"    {'; '.join(ras)}")
        w(f"    {'config':<10} {'n':>2} {'T MiB/s':>9} {'p50 µs':>9} {'p99 µs':>9} "
          f"{'disco/fio':>9} {'fila':>6} {'req KiB':>8}")
        for cfg in ["nativo"] + fuses:
            v = execs.get((cond, cfg), [])
            if not v:
                continue
            med = lambda k: st.median([e[k] for e in v])
            w(f"    {cfg:<10} {len(v):>2} {fmt(med('T'),1):>9} {fmt(med('p50'),0):>9} "
              f"{fmt(med('p99'),0):>9} {fmt(med('disco_fio')):>9} {fmt(med('aqu')):>6} "
              f"{fmt(med('rsz'),0):>8}")
        nat = execs[(cond, "nativo")]
        for cfg in fuses:
            f = execs.get((cond, cfg), [])
            if len(f) < 2 or len(nat) < 2:
                continue
            r = {m: st.median([e[m] for e in f]) / st.median([e[m] for e in nat]) for m in METRICAS}
            c14 = (r["T"] >= 1 - EPS and all(r[m] <= 1 + DELTA for m in METRICAS[1:]))
            testes = {m: mann_whitney([e[m] for e in f], [e[m] for e in nat],
                                      maior_melhor=(m == "T"), tol=EPS if m == "T" else DELTA)
                      for m in METRICAS}
            c5 = all(p <= ALPHA for _, p in testes.values())
            classe = "satisfaz" if c14 and c5 else ("inconclusiva" if c14 else "não satisfaz")
            w(f"    {cfg}: R_T={fmt(r['T'])}  R50={fmt(r['p50'])}  R95={fmt(r['p95'])}  "
              f"R99={fmt(r['p99'])}  ->  {classe}")
            w("      U/p: " + "  ".join(f"{m}: U={testes[m][0]:g} p={fmt(testes[m][1],3)}"
                                        for m in METRICAS))

    # Leitura guiada
    def rt(cond, cfg):
        f, n = execs.get((cond, cfg)), execs.get((cond, "nativo"))
        return st.median([e["T"] for e in f]) / st.median([e["T"] for e in n]) if f and n else float("nan")
    w("\nLeitura dos resultados:")
    for cfg in fuses:
        a, b, c = rt("padrao", cfg), rt("semdica", cfg), rt("semra", cfg)
        w(f"  {cfg}: R_T padrao {fmt(a)} | semdica {fmt(b)} | semra {fmt(c)}")
    w("  - padrao deve reproduzir a coleta (R_T ~1,29 no FUSE-mt). Se não reproduzir, pare e")
    w("    confira o ambiente antes de interpretar o resto.")
    w("  - semdica: se R_T cai para ~1 ou abaixo, a vantagem vinha de o NATIVO estar sem")
    w("    readahead por causa da dica do fio.")
    w("  - semra: se R_T cai para ~1 ou abaixo, a vantagem vinha do readahead do daemon.")
    w("  - As duas juntas confirmam o mecanismo pelos dois lados. Confira também o disco/fio")
    w("    (os ~10% a mais lidos pelo FUSE devem sumir em semra) e a fila média.\n")


# ====================================================================== P4
ATRIB = {"newfstatat", "fstatat64", "fstat", "statx", "lstat", "stat"}
DADOS = {"pread64", "preadv", "preadv2", "read_data"}  # leituras no arquivo do ext4


def ler_strace(caminho):
    cont = {}
    try:
        for linha in open(caminho, encoding="utf-8", errors="replace"):
            p = linha.split()
            if len(p) >= 5 and re.match(r"^[\d.]+$", p[0]) and p[3].isdigit():
                cont[p[-1]] = int(p[3])
    except OSError:
        pass
    return cont


def p4(base, w):
    w("=" * 78)
    w("P4 — Consultas de atributos ao daemon por read() (leitura sequencial de 4 KiB)")
    w("=" * 78)
    achou = False
    for cfg in ["fuse-base", "fuse-cache"]:
        arq = os.path.join(base, "p4", f"{cfg}.json")
        if not os.path.isfile(arq):
            continue
        achou = True
        d = ler_json(arq)["jobs"][0]["read"]
        ios = d["total_ios"]
        s = ler_strace(os.path.join(base, "p4", f"{cfg}.strace.txt"))
        atrib = sum(v for k, v in s.items() if k in ATRIB)
        dados = sum(v for k, v in s.items() if k in DADOS)
        req = s.get("read", 0) + s.get("splice", 0)   # requisições lidas de /dev/fuse
        resp = s.get("writev", 0) + s.get("write", 0)
        w(f"\n--- {cfg}  (fio: {ios} read() de 4 KiB em 10 s, {fmt(d['bw_bytes']/2**20,1)} MiB/s com strace)")
        w(f"    chamadas de atributos (newfstatat/statx/fstat): {atrib:>9}   por read() do fio: {fmt(atrib/ios if ios else float('nan'),3)}")
        w(f"    leituras de dados no ext4 (pread64/preadv):     {dados:>9}   por read() do fio: {fmt(dados/ios if ios else float('nan'),3)}")
        w(f"    requisições lidas de /dev/fuse (read/splice):   {req:>9}")
        w(f"    respostas ao kernel (writev/write):             {resp:>9}")
        outros = sorted(((v, k) for k, v in s.items() if k not in ATRIB | DADOS | {"read", "splice", "writev", "write", "total"}), reverse=True)[:6]
        if outros:
            w("    outras chamadas: " + ", ".join(f"{k} {v}" for v, k in outros))
    if not achou:
        w("Nenhum resultado em p4/.\n")
        return
    w("\nLeitura dos resultados:")
    w("  - FUSE-base com ~1 chamada de atributos por read() do fio, e FUSE-cache com quase")
    w("    nenhuma, demonstra a revalidação (attr_timeout = 0 + AUTO_INVAL_DATA).")
    w("  - As leituras de dados devem ser muito menos que os read() (o readahead do FUSE")
    w("    agrupa as leituras de 4 KiB em requisições de até 128 KiB).")
    w("  - O strace deixa o daemon bem mais lento; isso não afeta as contagens por read().\n")


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    base = sys.argv[1]
    linhas = []
    w = linhas.append
    p1(base, w)
    p4(base, w)
    texto = "\n".join(linhas)
    print(texto)
    open(os.path.join(base, "relatorio_p1_p4.txt"), "w", encoding="utf-8").write(texto + "\n")


if __name__ == "__main__":
    main()
