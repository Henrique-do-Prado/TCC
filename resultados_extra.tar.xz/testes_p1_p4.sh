#!/usr/bin/env bash
# testes_p1_p4.sh — Testes complementares pedidos na revisão de 16/11/2026
#
# P1  Leitura aleatória de 1 MiB, 1 job: por que o FUSE é mais rápido que o NATIVO?
#     Hipótese: o fio (fadvise_hint=1, padrão) chama posix_fadvise(RANDOM), que
#     desliga o readahead no arquivo aberto pelo NATIVO. O FUSE não repassa a dica
#     ao daemon, cujo descritor no ext4 continua com readahead.
#     Três condições, NATIVO e FUSE-mt, 5 repetições cada, na MESMA sessão:
#       padrao   igual à coleta (fadvise_hint padrão)          -> controle
#       semdica  fadvise_hint=0: o NATIVO também tem readahead -> o NATIVO alcança?
#       semra    dica padrão, readahead do dispositivo do ext4 = 0
#                (tira o readahead do daemon)                  -> o FUSE perde a vantagem?
#     30 execuções, ~24 min.
#
# P4  FUSE-base (--nocache): há uma consulta de atributos (GETATTR) ao daemon por read()?
#     Leitura sequencial de 4 KiB, 1 job, 10 s, com strace -c no daemon.
#     FUSE-cache como controle. ~1 min.
#
# Uso (como root, em modo texto, na tomada, perfil performance):
#   sudo PT_HP=/home/hen/tcc-scripts/coleta/libfuse/example/passthrough_hp ./testes_p1_p4.sh
#   sudo FAZER=p4 ...        só o P4 (também: FAZER=p1)
#   sudo P1_CONDS="padrao semdica" ...   P1 sem a condição semra (~16 min)
#   LISTAR=1 ./testes_p1_p4.sh           mostra a ordem do P1, sem executar
#
# Retomável: execuções com JSON final já gravado são puladas.
# Resultados em ./resultados_extra/{p1,p4}/. Analise com analisa_p1_p4.py.

set -uo pipefail

# ------------------------------------------------------------- configuração
PT_HP="${PT_HP:-/home/hen/tcc-scripts/coleta/libfuse/example/passthrough_hp}"
SRC_DIR="${SRC_DIR:-/srv/fusebench/base}"
MNT="${MNT:-/srv/fusebench/mnt}"
DEV="${DEV:-/dev/nvme0n1}"
BASE="${BASE:-$PWD/resultados_extra}"
KERNEL_ESPERADO="${KERNEL_ESPERADO:-7.1.1-76070101-generic}"
FAZER="${FAZER:-p1 p4}"
P1_CONDS="${P1_CONDS:-padrao semdica semra}"
P1_CONFIGS="${P1_CONFIGS:-nativo fuse-mt}"
LISTAR="${LISTAR:-0}"

FILE_GIB=80
RUNTIME=40
RAMP=5
REPS=5
SEED=20261116

opcoes_fuse() {
  case "$1" in
    fuse-base)   echo "--nocache --nosplice --single" ;;
    fuse-cache)  echo "--nosplice --single" ;;
    fuse-splice) echo "--nocache --single" ;;
    *)           echo "" ;;
  esac
}

log() { printf '[%(%d/%m %H:%M:%S)T] %s\n' -1 "$*"; }
die() { log "ERRO: $*"; exit 1; }

# ------------------------------------------------------- ordem do P1
# 5 repetições; dentro de cada uma, as combinações condição × configuração em
# ordem aleatória própria (mesma receita de semente do coleta.sh).
fonte_aleatoria() {
  openssl enc -aes-256-ctr -pass pass:"$1" -nosalt -pbkdf2 < /dev/zero 2>/dev/null
}
ordem_p1=()
for r in $(seq "$REPS"); do
  combos=()
  for cond in $P1_CONDS; do
    for cfg in $P1_CONFIGS; do combos+=("$r $cond $cfg"); done
  done
  mapfile -t emb < <(printf '%s\n' "${combos[@]}" | shuf --random-source=<(fonte_aleatoria "$((SEED + r))"))
  ordem_p1+=("${emb[@]}")
done

if [[ "$LISTAR" == 1 ]]; then
  printf '%s\n' "${ordem_p1[@]}"
  exit 0
fi

# ---------------------------------------------------------- pré-requisitos
[[ $EUID -eq 0 ]] || die "execute como root (sudo)."
for cmd in fio iostat fusermount3 mountpoint findmnt shuf stdbuf blockdev openssl pgrep; do
  command -v "$cmd" > /dev/null || die "comando ausente: $cmd."
done
if [[ " $FAZER " == *" p4 "* ]] && ! command -v strace > /dev/null; then
  die "strace ausente (sudo apt install strace)."
fi
[[ -x "$PT_HP" ]] || die "passthrough_hp não encontrado em '$PT_HP'."
[[ "$(uname -r)" == "$KERNEL_ESPERADO" ]] || die "kernel atual é '$(uname -r)', esperado '$KERNEL_ESPERADO'."
TESTFILE="$SRC_DIR/teste.dat"
[[ "$(stat -c %s "$TESTFILE" 2>/dev/null || echo 0)" -eq $((FILE_GIB * 1024**3)) ]] || \
  die "arquivo de teste $TESTFILE ausente ou com tamanho diferente do da coleta."
perfil=$(system76-power profile 2>/dev/null | head -n1 || echo desconhecido)
grep -qi performance <<< "$perfil" || log "AVISO: perfil de energia é '$perfil' (a coleta usou performance)."
systemctl is-active --quiet graphical.target && log "AVISO: interface gráfica ativa (a coleta foi em modo texto)."

# Dispositivo que contém o ext4 (o LV sobre o LUKS): é o readahead dele que vale
# para os arquivos do ext4, inclusive o descritor aberto pelo daemon do FUSE.
RA_DEV=$(findmnt -no SOURCE -T "$SRC_DIR")
[[ -b "$RA_DEV" ]] || die "não achei o dispositivo de bloco de $SRC_DIR (findmnt deu '$RA_DEV')."
RA_ORIG=$(blockdev --getra "$RA_DEV")

FUSE_PID=""
IOSTAT_PID=""
STRACE_PID=""
desmontar() {
  if mountpoint -q "$MNT" 2>/dev/null; then
    fusermount3 -u "$MNT" 2>/dev/null || umount "$MNT" 2>/dev/null || umount -l "$MNT"
  fi
  [[ -n "$FUSE_PID" ]] && { wait "$FUSE_PID" 2>/dev/null || true; FUSE_PID=""; }
}
parar() {
  [[ -n "$STRACE_PID" ]] && { kill -INT "$STRACE_PID" 2>/dev/null; wait "$STRACE_PID" 2>/dev/null; STRACE_PID=""; }
  [[ -n "$IOSTAT_PID" ]] && { kill "$IOSTAT_PID" 2>/dev/null; wait "$IOSTAT_PID" 2>/dev/null; IOSTAT_PID=""; }
}
limpar() {
  parar
  desmontar
  blockdev --setra "$RA_ORIG" "$RA_DEV" 2>/dev/null && log "readahead de $RA_DEV restaurado para $RA_ORIG setores."
}
trap limpar EXIT
trap 'log "Interrompido."; exit 130' INT TERM

montar_fuse() {  # $1 = configuração, $2 = log
  local -a opts
  read -r -a opts <<< "$(opcoes_fuse "$1")"
  "$PT_HP" "${opts[@]}" "$SRC_DIR" "$MNT" > "$2" 2>&1 &
  FUSE_PID=$!
  for _ in $(seq 50); do mountpoint -q "$MNT" && return 0; sleep 0.2; done
  return 1
}

preparar() {  # sincroniza e limpa caches, como na coleta
  desmontar
  sync
  echo 3 > /proc/sys/vm/drop_caches
}

mkdir -p "$BASE/p1" "$BASE/p4"
{
  echo "data: $(date -Is)"
  echo "kernel: $(uname -r)"
  echo "fio: $(fio --version)"
  echo "passthrough_hp: $PT_HP"
  echo "perfil de energia: $perfil"
  echo "interface grafica ativa: $(systemctl is-active graphical.target 2>/dev/null || true)"
  echo "dispositivo do ext4 (readahead): $RA_DEV, readahead original: $RA_ORIG setores"
  echo "P1: condicoes=($P1_CONDS) configs=($P1_CONFIGS) reps=$REPS"
} > "$BASE/ambiente_$(date +%s).txt"

# ====================================================================== P1
if [[ " $FAZER " == *" p1 "* ]]; then
  total=${#ordem_p1[@]}
  log "P1: $total execuções (~$(( total * (RUNTIME + RAMP + 3) / 60 )) min)."
  i=0
  for linha in "${ordem_p1[@]}"; do
    i=$((i + 1))
    read -r r cond cfg <<< "$linha"
    id="${cond}_${cfg}_r${r}"
    p="$BASE/p1/$id"
    [[ -s "$p.json" ]] && continue
    log "[P1 $i/$total] $cond  $cfg  rep $r"

    preparar
    if [[ "$cond" == semra ]]; then ra=0; else ra=$RA_ORIG; fi
    blockdev --setra "$ra" "$RA_DEV"

    if [[ "$cfg" == nativo ]]; then
      alvo="$TESTFILE"
    else
      montar_fuse "$cfg" "$p.fuse.log" || { log "  FALHA ao montar; pulando."; desmontar; continue; }
      alvo="$MNT/teste.dat"
    fi

    args=(--name="$id" --filename="$alvo" --allow_file_create=0
          --ioengine=psync --direct=0 --iodepth=1 --rw=randread --bs=1m
          --numjobs=1 --size="${FILE_GIB}g"
          --randseed=$((SEED * 1000 + i)) --group_reporting=1
          --ramp_time="$RAMP" --runtime="$RUNTIME" --time_based=1
          --output-format=json+ --output="$p.json.tmp")
    [[ "$cond" == semdica ]] && args+=(--fadvise_hint=0)

    echo "readahead=$(blockdev --getra "$RA_DEV")" > "$p.info"
    LC_ALL=C stdbuf -oL iostat -dxmty 1 "$(basename "$DEV")" > "$p.iostat.txt" &
    IOSTAT_PID=$!
    if fio "${args[@]}" > "$p.fio.log" 2>&1 && [[ -s "$p.json.tmp" ]]; then
      mv "$p.json.tmp" "$p.json"
    else
      log "  FALHA no fio (veja $p.fio.log)."
    fi
    parar
    desmontar
  done
  blockdev --setra "$RA_ORIG" "$RA_DEV"
  log "P1 concluído."
fi

# ====================================================================== P4
if [[ " $FAZER " == *" p4 "* ]]; then
  for cfg in fuse-base fuse-cache; do
    p="$BASE/p4/$cfg"
    [[ -s "$p.json" ]] && continue
    log "[P4] $cfg: leitura sequencial de 4 KiB, 10 s, strace -c no daemon"
    preparar
    montar_fuse "$cfg" "$p.fuse.log" || { log "  FALHA ao montar; pulando."; desmontar; continue; }
    pid=$(pgrep -n -x passthrough_hp) || { log "  daemon não encontrado; pulando."; desmontar; continue; }
    # -f com -p acompanha todas as threads do processo (aqui há uma só: --single)
    strace -c -f -p "$pid" -o "$p.strace.txt" 2> "$p.strace.err" &
    STRACE_PID=$!
    sleep 1
    fio --name="p4_$cfg" --filename="$MNT/teste.dat" --allow_file_create=0 \
        --ioengine=psync --direct=0 --iodepth=1 --rw=read --bs=4k --numjobs=1 \
        --size="${FILE_GIB}g" --runtime=10 --time_based=1 \
        --output-format=json --output="$p.json.tmp" > "$p.fio.log" 2>&1
    sleep 1
    parar           # SIGINT no strace: ele se desanexa e grava o resumo
    desmontar
    [[ -s "$p.json.tmp" ]] && mv "$p.json.tmp" "$p.json" || log "  FALHA no fio (veja $p.fio.log)."
  done
  log "P4 concluído."
fi

log "Fim. Rode: python3 analisa_p1_p4.py $BASE"
